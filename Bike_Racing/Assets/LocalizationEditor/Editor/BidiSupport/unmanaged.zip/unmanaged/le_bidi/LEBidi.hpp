#ifndef _LEBIDI_HPP_
#define _LEBIDI_HPP_

extern "C"
{
    void GetBidi(const char* in_logical_utf8, int logical_len, char* out_visual_utf8, int visual_len);
}
#endif
