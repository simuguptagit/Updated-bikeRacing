#include "LEBidi.hpp"
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <sstream>
#include <string>

#define MAX_STR_LEN 65000

using namespace std;

extern "C" {
#include <fribidi/fribidi.h>
}

string makebidi(const string &buf, int lpad)
{
    FriBidiCharSet utf8 = fribidi_parse_charset ("UTF-8");
    FriBidiChar *out_visual_ucs4;
    char *logical;
    FriBidiCharType base = FRIBIDI_TYPE_ON;
    string r, pad;
    FriBidiStrIndex len;
    FriBidiStrIndex new_len;
    fribidi_boolean log2vis;

    FriBidiChar logical_ucs4[MAX_STR_LEN];
    char out_visual_utf8[MAX_STR_LEN];
    logical = strdup(buf.c_str()); // allocated by strdup with malloc needs to be freed

    // utf-8 ==> ucs4 (4 byte unicode)
    len = fribidi_charset_to_unicode(utf8, logical, buf.size(), logical_ucs4);

    // allocate out logical str; add null terminator
    out_visual_ucs4 = new FriBidiChar[len+1];

    log2vis = fribidi_log2vis(logical_ucs4, len, &base, out_visual_ucs4, 0, 0, 0);
    if (log2vis == 0) return "";

    new_len = fribidi_unicode_to_charset(utf8, out_visual_ucs4, len, out_visual_utf8);
    r = out_visual_utf8;
    cout << "new_len: " << new_len << endl;
    cout << "r.size(): " << r.size() << endl;
    delete out_visual_ucs4;
    free (logical); /* allocated by c-routine strdup*/

    if(lpad) {
	pad.assign(lpad-r.size(), ' ');
	r.insert(0, pad);
    }

    return r;
}

void GetBidi(const char* in_logical_utf8, int logical_len, char* out_visual_utf8, int visual_len)
{
    string logical_utf8(in_logical_utf8);
    string visual_utf8 = makebidi(logical_utf8, 0);

    if (visual_utf8.size() > (unsigned int) visual_len)
    {
      //TODO error handling out of mem
    }
    else
    {
        strcpy(out_visual_utf8, visual_utf8.c_str());
    }
}
