**** Building fribidi ****

We use GNU fribidi, which provides the Unicode BIDI algorithm for RTL
languages such as Arabic & Hebrew. This uses the autotools to build
(configure,make,make install).

We are building a universal binary ie. "fat" (has both 32 & 64 bit
included) shared library and opening it ourselves with dlopen dlsym.

Build 32 Bit
cd unmanaged
git clone http://anongit.freedesktop.org/git/fribidi/fribidi.git
cd fribidi
./bootstrap
./configure --prefix='/usr/local/lib/fribidi_i386' --enable-static --with-glib=no "CFLAGS=-m32"
make
make install

Build 64 Bit
./configure --prefix='/usr/local/lib/fribidi_x64' --enable-static --with-glib=no
make
make install

Note: On OSX we need to make a symlink to the static lib so we link
with the static version of libfribidi. The linker picks the dynamic
lib by default.  We override this with the symlink.

ln -s /usr/local/lib/fribidi_i386/lib/libfribidi.a /usr/local/lib/fribidi_i386/lib/libfribidi_s.a
ln -s /usr/local/lib/fribidi_x64/lib/libfribidi.a /usr/local/lib/fribidi_x64/lib/libfribidi_s.a
**************************

**** Building lebidi ****

This is the dll that we call into from the C# side of things. It
contains one function where we pass it a UTF8 string and we get back a
UTF8 string.  It uses the Unicode BIDI algorithm provided by fribidi
to do the character reordering and shaping for Arabic.

We use scons to build this since it's C++ so it's much easier. 64bit
build is default. Build both 32 & 64 bit and put them together with
lipo to get a universal binary. Check that both architectures are
included with 'file' command.

Build 32 bit
scons arch=i386

64 bit build
scons

Stick them both together.
lipo -create <32 bit dylib> <64 bit dylib> -output lebidi-fat-osx.dylib
file lebidi-fat-osx.dylib (check to make sure both 32 & 64 bit libs are there)
**************************

*** Deploying to Unity ***

Copy lebidi-fat-osx.dylib to Assets/LocalizationEditor/Editor/BidiSupport/lebidi-osx.dylib
Verify the Unity import settings are set to OSX only
**************************
