Building lebidi.dll
Install Msys2

Unity 4x needs 32bit dll so open a MinGW-w64 Win32 Shell
Unity 5x needs 64bit dll so open a MinGW-W64 Win64 Shell

**** Building fribidi ****

We use GNU fribidi, which provides the Unicode BIDI algorithm for RTL
languages such as Arabic & Hebrew. This uses the autotools to build
(configure,make,make install) so we need that toolchain on Windows.
Msys2 provides this and we want to build a 64bit dll so we use the W64
Shell and the correct versions of the compiler are used.

cd unmanaged
git clone http://anongit.freedesktop.org/git/fribidi/fribidi.git
cd fribidi
./bootstrap
./configure --enable-static --with-glib=no

make

Note: On Windows this fails to build the exe that comes along with
fribidi.  We are only using the lib which builds ok so ignore the
errors on building fribidi.exe.

make install

**************************

**** Building lebidi ****

This is the dll that we call into from the C# side of things. It
contains one function where we pass it a UTF8 string and we get back a
UTF8 string.  It uses the Unicode BIDI algorithm provided by fribidi
to do the character reordering and shaping.

We use scons to build this since it's C++ so it's much easier. 64bit build is default.

scons
scons install
**************************

*** Deploying to Unity ***

Once installed with scons: 

Delete lebidi.dll.a from the install directory (Assets/LocalizationEditor/Editor/BidiSupport)
rename the DLL to lebidi-win.dll
Verify the Unity import settings are set to Windows only
**************************
