The source for fribidi can be obtained at the github address below or
check their website. The license is in the file COPYING.

https://github.com/behdad/fribidi
http://fribidi.org/
